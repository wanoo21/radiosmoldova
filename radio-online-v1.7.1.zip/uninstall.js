
"use strict";((global)=>{const background=chrome.extension.getBackgroundPage();})(window)